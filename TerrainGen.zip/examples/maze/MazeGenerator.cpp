#include "MazeGenerator.h"
#include "World.h"

bool MazeGenerator::Step(World* world) {
  return false;
}
void MazeGenerator::Clear(World* world) {}
