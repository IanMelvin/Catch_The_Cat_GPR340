#ifndef MOBAGEN_ENGINE_JOBMANAGER_H_
#define MOBAGEN_ENGINE_JOBMANAGER_H_

class JobManager {
 public:
  static bool IsRunningInMainThread();
};

#endif //MOBAGEN_ENGINE_JOBMANAGER_H_
