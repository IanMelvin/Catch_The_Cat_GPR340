//#ifndef MOBAGEN_ENGINE_GLEWMANAGER_H_
//#define MOBAGEN_ENGINE_GLEWMANAGER_H_
//// todo: do we really need this?
//class GLEWManager {
// public:
//  GLEWManager();
//  ~GLEWManager();
//};
//
//#endif //MOBAGEN_ENGINE_GLEWMANAGER_H_
