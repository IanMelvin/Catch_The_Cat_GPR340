#ifndef MOBAGEN_ENGINE_UTILS_H_
#define MOBAGEN_ENGINE_UTILS_H_

class Utils {
};

#endif //MOBAGEN_ENGINE_UTILS_H_
