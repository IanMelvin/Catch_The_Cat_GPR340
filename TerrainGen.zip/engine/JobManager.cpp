#include "JobManager.h"
bool JobManager::IsRunningInMainThread() {
  // todo: implement
  return true;
}
