Bug
===

Sections render a little bit ugly because bottom properties calculated wrongly.

Example 1
---------

Should be:

.. seealso::

  * Link

.. seealso::

  * Link

.. seealso::

  * Link

Looks now:

.. seealso::

  * Link

.. admonition:: Examples on GitHub

  * Link

.. seealso::

  * Link

Example 1
---------

Should be:

.. seealso::

  Some text

.. seealso::

  Some text

.. seealso::

  Some text

Looks now:

.. seealso::

  Some text

.. admonition:: Examples on GitHub

  Some text

.. seealso::

  Some text
