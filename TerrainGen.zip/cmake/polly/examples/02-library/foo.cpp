#include <iostream> // std::cout

int foo() {
  std::cout << "Hello from foo" << std::endl;
  return 42;
}
