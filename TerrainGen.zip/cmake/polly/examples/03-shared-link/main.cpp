#include <iostream>

int boo();

int main() {
  std::cout << "Boo say:" << std::endl;
  boo();
}
