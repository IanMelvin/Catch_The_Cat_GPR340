#ifndef INPUT_H
#define INPUT_H

#include "Vector2.h"

class Input {

};


#endif
