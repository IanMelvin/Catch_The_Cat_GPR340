#ifndef VECTOR4_H
#define VECTOR4_H

struct Vector4 {

};

#endif
